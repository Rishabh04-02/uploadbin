#include<iostream>
#include<stdio.h>
#include<bits/stdc++.h>
using namespace std;
#define mod 10001
int main()
{
	int t=100;
	printf("%d\n",t);
	srand(time(NULL));
	for(int i=1;i<=t;i++)
	{
		int n=rand()%mod;
		cout<<n<<endl;
	}
}
